/**
 * Programmer: Khoi Ho
 * DescriptionL This program tests connection to a MySQL database.
 */

import java.sql.*;

public class TestConnectionToDataBase
{
    public static void main(String[] args) throws SQLException, ClassNotFoundException
    {
        // Load the driver.
        Class.forName("com.mysql.jdbc.Driver");
        System.out.println("Driver loaded.");
        
        // Connect to the database
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/hospitalmanagementsystem", "root", "root");
        System.out.println("Database connected.");
        
        // Create an SQL statement. In this case, we try to add a record to Room.
        String query = " insert into Room (roomID, roomName)" + " values (?, ?)";      
        PreparedStatement preparedStmt = connection.prepareStatement(query);
        preparedStmt.setInt(1, 1);
        preparedStmt.setString(2, "Emergency Room");
        
        // Execute the statement.
        preparedStmt.execute();
        
        // Close the database.
        connection.close();
    }
}
