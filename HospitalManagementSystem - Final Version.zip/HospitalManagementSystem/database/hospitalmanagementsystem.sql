-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: hospitalmanagementsystem
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `appointment`
--

DROP TABLE IF EXISTS `appointment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appointment` (
  `appointmentID` int unsigned NOT NULL,
  `patientID` int unsigned NOT NULL,
  `doctorID` int unsigned NOT NULL,
  `roomID` int unsigned NOT NULL,
  `date` date NOT NULL,
  `startTime` time NOT NULL,
  `endTime` time NOT NULL,
  `note` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`appointmentID`),
  UNIQUE KEY `appointmentID_UNIQUE` (`appointmentID`),
  KEY `patientID_idx` (`patientID`),
  KEY `doctorID_idx` (`doctorID`),
  KEY `roomID_idx` (`roomID`),
  CONSTRAINT `doctorID` FOREIGN KEY (`doctorID`) REFERENCES `doctor` (`doctorID`),
  CONSTRAINT `patientID` FOREIGN KEY (`patientID`) REFERENCES `patient` (`medicalRecordNumber`),
  CONSTRAINT `roomID` FOREIGN KEY (`roomID`) REFERENCES `room` (`roomID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Stores data about appointments';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointment`
--

LOCK TABLES `appointment` WRITE;
/*!40000 ALTER TABLE `appointment` DISABLE KEYS */;
INSERT INTO `appointment` VALUES (0,2,4,3,'2020-11-25','16:30:00','17:30:00','Please bring all required documents to the doctor.'),(1,1,4,1,'2020-11-27','15:30:00','16:00:00',''),(2,4,0,2,'2020-11-27','13:30:00','14:30:00',''),(3,2,0,3,'2020-11-27','15:30:00','16:30:00',''),(4,2,0,1,'2020-10-06','16:00:00','16:30:00',''),(5,2,0,3,'2020-11-28','15:30:00','16:30:00',''),(6,0,0,1,'2020-11-27','17:30:00','18:00:00','');
/*!40000 ALTER TABLE `appointment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctor`
--

DROP TABLE IF EXISTS `doctor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctor` (
  `doctorID` int unsigned NOT NULL,
  `firstName` varchar(45) NOT NULL,
  `middleName` varchar(45) DEFAULT NULL,
  `lastName` varchar(45) NOT NULL,
  `isFemale` tinyint DEFAULT NULL,
  `dateOfBirth` date NOT NULL,
  `phoneNumber` varchar(10) NOT NULL,
  `homeAddress` varchar(100) NOT NULL,
  `emailAddress` varchar(45) NOT NULL,
  `department` varchar(45) NOT NULL,
  PRIMARY KEY (`doctorID`),
  UNIQUE KEY `doctorID_UNIQUE` (`doctorID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Stores data about doctors';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctor`
--

LOCK TABLES `doctor` WRITE;
/*!40000 ALTER TABLE `doctor` DISABLE KEYS */;
INSERT INTO `doctor` VALUES (0,'Laura','T','Anderson',1,'1989-12-04','4132795182','16 Tampa St., Boston, MA, 01844','laura@gmail.com','Neurology'),(1,'David','T.','Jackson',0,'1972-07-01','4192732672','62 Tampa St., Boston, MA 01762','davidj23@gmail.com','Cardiology'),(2,'Logan','T.','Jackson',0,'1979-07-01','4192732672','62 Tampa St., Boston, MA 01762','davidj23@gmail.com','Cardiology'),(3,'Henry','P.','Drake',0,'1979-09-04','8972563710','338 Nelm St., Beltsville, VA 20705','hendryd@gmail.com','Radiology'),(4,'Robert','K.','Marston',0,'1980-10-16','8275167953','473 Jackson Ave, Kingston, MA 09766','marston7562@hotmail.com','Dentistry'),(5,'David','J.','Jefferson',0,'1956-09-10','4172985834','30 Temple Dr, Methuen MA','smith16@gmail.com','Dentistry'),(6,'Thomas','S.','Logarson',0,'1976-10-05','4285193760','47 Brookdale Rd., Quincy, MA 01763','thomas18@gmail.com','Psychology'),(7,'Anna','T.','Dennis',1,'1988-01-28','4895172962','16 Harrison Rd, Salt Lake, MA 08927','anna453@hotmail.com','Radiology'),(8,'Sarah','','Floyd',1,'1988-12-06','4792875713','56 Washington St., Quincy, MA 09784','fsarah@yahoo.com','Orthopaedics'),(9,'Francis','','Florczack',0,'1993-06-14','4192875603','79 Robinson St., Boston, 01973','francis13@gmail.com','Oncology');
/*!40000 ALTER TABLE `doctor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient` (
  `medicalRecordNumber` int unsigned NOT NULL,
  `firstName` varchar(45) NOT NULL,
  `middleName` varchar(45) DEFAULT NULL,
  `lastName` varchar(45) NOT NULL,
  `isFemale` tinyint DEFAULT NULL,
  `dateOfBirth` date NOT NULL,
  `phoneNumber` varchar(10) NOT NULL,
  `homeAddress` varchar(100) NOT NULL,
  `emailAddress` varchar(45) DEFAULT NULL,
  `assignedDoctorID` int unsigned DEFAULT NULL,
  PRIMARY KEY (`medicalRecordNumber`),
  UNIQUE KEY `medicalRecordNumber_UNIQUE` (`medicalRecordNumber`),
  KEY `assignedDoctorID_idx` (`assignedDoctorID`),
  CONSTRAINT `assignedDoctorID` FOREIGN KEY (`assignedDoctorID`) REFERENCES `doctor` (`doctorID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Stores data about patients';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient`
--

LOCK TABLES `patient` WRITE;
/*!40000 ALTER TABLE `patient` DISABLE KEYS */;
INSERT INTO `patient` VALUES (0,'Thomas','J.','Smith',0,'1980-07-01','4147879820','22 David Rd., Boston, MA 01277','smith16@outlook.com',NULL),(1,'Joseph','M.','Lee',0,'1949-09-12','4165782904','16 Pine Rd., Kingston, MA 09457','',NULL),(2,'Aileen','J.','Guertin',1,'1985-08-02','2625366249','2548 Whaley Lane, Milwaukee, WI 53202','tqn1f4s4chq@temporary-mail.net',NULL),(3,'Rick','J.','White',0,'1963-05-22','3154510874','3650 Buckhannan Avenue, Liverpool, NY 13088','gpshb0r479@temporary-mail.net',NULL),(4,'Rusell','M.','Parson',0,'1985-04-20','6037419570','499 Milford Street, Richfield Springs, NY 13439','bzu1k3f7ryl@temporary-mail.net',NULL),(5,'Lena','L.','Woodruff',1,'1984-03-30','2122375207','1625 Bell Street, New York City, NY 10019','rs5xofpc2q@temporary-mail.net',NULL),(6,'Jesse','M.','Arellano',0,'1993-12-14','6188252279','2388 Carter Street, Belleville, IL 62220','knjx329fwla@temporary-mail.net',NULL),(7,'Eddie','K.','Johnson',0,'1984-02-27','5872167813','45 Brookdale St., Methuen, MA 01563','johnson17@gmail.com',NULL);
/*!40000 ALTER TABLE `patient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room` (
  `roomID` int unsigned NOT NULL,
  `roomName` varchar(45) NOT NULL,
  PRIMARY KEY (`roomID`),
  UNIQUE KEY `roomID_UNIQUE` (`roomID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Stores data about rooms';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES (0,'Consultant Room 1'),(1,'Consultant Room 2'),(2,'Consultant Room 3'),(3,'Emergency Room'),(4,'Operating Room');
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-27 10:46:30
