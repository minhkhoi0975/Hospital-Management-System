package CSC285.project.hospitalmanagementsystem.presentation.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ShowADoctorsAllAppointments extends HttpServlet
{
    final static String DATABASE_URL = "jdbc:mysql://localhost/hospitalmanagementsystem";
    final static String USERNAME = "root";
    final static String PASSWORD = "root";
    
    static Connection connection = null;
    
    public void init() throws ServletException
    {
        try
        {
             connectToDatabase();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
              
        // Review the data.
        try (PrintWriter out = response.getWriter())
        {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Show a Doctor's all Appointments</title>");  
            out.println("<style>");
            out.println("table, th, td {");
            out.println("border: 1px solid black;");
            out.println("border-collapse: collapse;");
            out.println("}");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");
            
            // Get data from the HTML page.
            String doctorID = request.getParameter("doctorID").trim();
            String includePastAppointments = request.getParameter("includePastAppointments") == null ? "false" : "true";
                     
            // Get the doctor from database.
            Statement getDoctorStmt = connection.createStatement();
            ResultSet doctor = getDoctorStmt.executeQuery("select * from Doctor where doctorID=" + doctorID);
            
            // Check if the doctor exists
            if(!doctor.first())
            {
                out.println("The doctor with ID " + doctorID + " does not exist.<br>");
            }
            
            else
            {
                // Show the doctor's full name.
                String doctorFullName = doctor.getString("firstName") + " " 
                        + (doctor.getString("middleName").equals("") ? "" : doctor.getString("middleName") + " ")
                        + (doctor.getString("lastName"));
                out.println("Doctor ID: <b>" + doctorID + "</b><br>");
                out.println("Name: <b>" + doctorFullName + "</b><br>");
                     
                // Show all the appointments of that doctor.
                Statement getAppointmentStmt = connection.createStatement();
                ResultSet appointments;            
                if(includePastAppointments.equals("true"))
                {
                    appointments = getAppointmentStmt.executeQuery("select * from Appointment where doctorID=" + doctorID + " order by date, startTime");
                }
                else
                {
                    appointments = getAppointmentStmt.executeQuery("select * from Appointment where doctorID=" + doctorID + " and date>=current_date() order by date, startTime");
                }
                     
                out.println("Include the appointments in the past? <b>" + includePastAppointments + "</b><br>");
                out.println("<table>");
                out.println("<tr>");
                out.println("<th>Appointment ID</th>");
                out.println("<th>Patient ID</th>");
                out.println("<th>Doctor ID</th>");
                out.println("<th>Room ID</th>");
                out.println("<th>Date</th>");
                out.println("<th>Start Time</th>");
                out.println("<th>End Time</th>");
                out.println("<th>Note</th>");
                out.println("</tr>");
                
                while(appointments.next())
                {
                    out.println("<tr>");
                    out.println("<td>" + appointments.getString("appointmentID") + "</td>");
                    out.println("<td>" + appointments.getString("patientID") + "</td>");
                    out.println("<td>" + appointments.getString("doctorID") + "</td>");
                    out.println("<td>" + appointments.getString("roomID") + "</td>");
                    out.println("<td>" + appointments.getString("date") + "</td>");
                    out.println("<td>" + appointments.getString("startTime") + "</td>");
                    out.println("<td>" + appointments.getString("endTime") + "</td>");
                    out.println("<td>" + appointments.getString("Note") + "</td>");
                    out.println("</tr>");
                }
                
                out.println("</table>");
            }
            
            out.println("</body>");
            out.println("</html>");
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo()
    {
        return "Short description";
    }// </editor-fold>

    public static void connectToDatabase() throws Exception
    {
        // Load the driver.
        Class.forName("com.mysql.jdbc.Driver");

        // Connect to the database
        connection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);    
    }  
}