package CSC285.project.hospitalmanagementsystem.presentation.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AssignDoctorToPatient extends HttpServlet
{
    final static String DATABASE_URL = "jdbc:mysql://localhost/hospitalmanagementsystem";
    final static String USERNAME = "root";
    final static String PASSWORD = "root";
    
    static Connection connection = null;
    
    public void init() throws ServletException
    {
        try
        {
             connectToDatabase();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
              
        // Review the data.
        try (PrintWriter out = response.getWriter())
        {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Assign a Doctor to a Patient</title>");            
            out.println("</head>");
            out.println("<body>");
            
            // Get patient ID and doctor ID.
            String patientID = request.getParameter("patientID").trim();
            String doctorID = request.getParameter("doctorID").trim();
                  
            // Get the patient from database.
            Statement getPatientStmt = connection.createStatement();
            ResultSet patient = getPatientStmt.executeQuery("select * from Patient where medicalRecordNumber=" + patientID);
                     
            // Get the doctor from database.
            Statement getDoctorStmt = connection.createStatement();
            ResultSet doctor = getDoctorStmt.executeQuery("select * from Doctor where doctorID=" + doctorID);
            
            // Check if the patient exists
            if(!patient.first())
            {
                out.println("The patient with ID " + patientID + " does not exist.<br>");
            }
            
            // Check if the doctor exists.
            else if(!doctor.first())
            {
                out.println("The doctor with ID " + doctorID + " does not exist.<br>");
            }
            
            // Assign the doctor to the patient.
            else
            {
                out.println("Patient ID: <b>" + patientID + "</b><br>");
                out.println("Doctor ID: <b>" + doctorID + "</b><br>");
                
                String query = "update patient set assignedDoctorID = ? where medicalRecordNumber = ?" ;
                PreparedStatement assignDoctorStmt = connection.prepareStatement(query);
                
                assignDoctorStmt.setInt(1, Integer.valueOf(doctorID));
                assignDoctorStmt.setInt(2, Integer.valueOf(patientID));
                
                assignDoctorStmt.executeUpdate();
                
                String patientFullName = patient.getString("firstName") + " " 
                        + (patient.getString("middleName").equals("") ? "" : patient.getString("middleName") + " ")
                        + (patient.getString("lastName"));
                
                String doctorFullName = doctor.getString("firstName") + " " 
                        + (doctor.getString("middleName").equals("") ? "" : doctor.getString("middleName") + " ")
                        + (doctor.getString("lastName"));
                
                out.println("<b>" + doctorFullName + " </b>has been assigned to <b>" + patientFullName + "</b>.");
            }
            
            out.println("</body>");
            out.println("</html>");
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo()
    {
        return "Short description";
    }// </editor-fold>

    public static void connectToDatabase() throws Exception
    {
        // Load the driver.
        Class.forName("com.mysql.jdbc.Driver");

        // Connect to the database
        connection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);    
    }  
}