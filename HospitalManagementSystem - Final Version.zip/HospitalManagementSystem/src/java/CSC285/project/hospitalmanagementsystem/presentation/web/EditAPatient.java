package CSC285.project.hospitalmanagementsystem.presentation.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class EditAPatient extends HttpServlet
{
    final static String DATABASE_URL = "jdbc:mysql://localhost/hospitalmanagementsystem";
    final static String USERNAME = "root";
    final static String PASSWORD = "root";
    
    static Connection connection = null;
    static PreparedStatement statement = null;
    
    public void init() throws ServletException
    {
        try
        {
             connectToDatabase();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
        
        // Retrieve data from the html page.
        String patientID = request.getParameter("patientID").trim();
        String firstName = request.getParameter("firstName").trim();
        String middleName = request.getParameter("middleName").trim();
        String lastName = request.getParameter("lastName").trim();
        String sex = request.getParameter("sex");
        String dateOfBirthString = request.getParameter("dateOfBirth");
        Date dateOfBirth = new Date();
        try
        {
            dateOfBirth = new SimpleDateFormat("yyyy-MM-dd").parse(dateOfBirthString);
        }
        catch(ParseException ex)
        {}           
        String phoneNumber = request.getParameter("phoneNumber").trim();
        String emailAddress = request.getParameter("emailAddress").trim();
        String homeAddress = request.getParameter("homeAddress").trim();
             
        // Review the data.
        try (PrintWriter out = response.getWriter())
        {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Edit a Patient</title>");            
            out.println("</head>");
            out.println("<body>");
            
            // Get the patient from database.
            Statement getPatientStmt = connection.createStatement();
            ResultSet patient = getPatientStmt.executeQuery("select * from Patient where medicalRecordNumber=" + patientID);
            
            // Check if the patient exists
            if(!patient.first())
            {
                out.println("The patient with ID " + patientID + " does not exist.<br>");
            }
            
            else
            {
                // Update the patient.
                try
                {                 
                    editAPatient(Integer.valueOf(patientID),
                            firstName, middleName, lastName,
                            sex.equals("Female"),
                            new java.sql.Date(dateOfBirth.getYear(), dateOfBirth.getMonth(), dateOfBirth.getDate()),
                            phoneNumber, homeAddress, emailAddress);   
                    
                    out.println("Review<br>");
                    out.println("Patient ID: <b>" + patientID + "</b><br>");
                    out.println("First Name: <b>" + firstName + "</b><br>");
                    out.println("Middle Name: <b>" + middleName + "</b><br>");
                    out.println("Last Name: <b>" + lastName + "</b><br>");
                    out.println("Sex: <b>" + sex + "</b><br>");
                    out.println("Date of Birth: <b>" + (dateOfBirth.getMonth() + 1) + "/" + dateOfBirth.getDate() + "/" + (dateOfBirth.getYear() + 1900) + "</b><br>");
                    out.println("Phone Number: <b>" + phoneNumber + "</b><br>");
                    out.println("Email Address: <b>" + emailAddress + "</b><br>");
                    out.println("Home Address: <b>" + homeAddress + "</b><br>");
                } 
                catch (Exception ex)
                {
                    ex.printStackTrace();
                }                       
            }
            
            out.println("</body>");
            out.println("</html>");       
        }
        catch(Exception ex)
        {}
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo()
    {
        return "Short description";
    }// </editor-fold>

    public static void connectToDatabase() throws Exception
    {
        // Load the driver.
        Class.forName("com.mysql.jdbc.Driver");

        // Connect to the database
        connection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);

        // Prepare the update statement.
        String query = "update Patient set "
                + "firstName=?, "
                + "middleName=?, "
                + "lastName=?, "
                + "isFemale=?, "
                + "dateOfBirth=?, "
                + "phoneNumber=?, "
                + "homeAddress=?, "
                + "emailAddress=? "
                + "where medicalRecordNumber=?";
        statement = connection.prepareStatement(query);      
    }
    
    public static void editAPatient(int id, 
            String firstName, String middleName, String lastName, 
            boolean isFemale, java.sql.Date dateOfBirth, 
            String phoneNumber, String homeAddress, String emailAddress) throws Exception
    {     
        statement.setString(1, firstName);
        statement.setString(2, middleName);
        statement.setString(3, lastName);
        statement.setInt(4, isFemale == true ? 1: 0);
        statement.setDate(5, dateOfBirth);
        statement.setString(6, phoneNumber);
        statement.setString(7, homeAddress);
        statement.setString(8, emailAddress);
        statement.setInt(9, id);
        statement.executeUpdate();
    }
}
