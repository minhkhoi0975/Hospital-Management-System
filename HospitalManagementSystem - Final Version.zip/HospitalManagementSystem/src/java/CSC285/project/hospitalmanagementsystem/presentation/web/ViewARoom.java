package CSC285.project.hospitalmanagementsystem.presentation.web;

import CSC285.project.hospitalmanagementsystem.dao.Util;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ViewARoom extends HttpServlet
{
    final static String DATABASE_URL = "jdbc:mysql://localhost/hospitalmanagementsystem";
    final static String USERNAME = "root";
    final static String PASSWORD = "root";
    
    static Connection connection = null;
    
    public void init() throws ServletException
    {
        try
        {
             connectToDatabase();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
        
        // Retrieve data from the html page.
        String roomID = request.getParameter("roomID").trim();
                  
        // Review the data.
        try (PrintWriter out = response.getWriter())
        {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>View a Room</title>");     
            out.println("<style>");
            out.println("table, th, td {");
            out.println("border: 1px solid black;");
            out.println("border-collapse: collapse;");
            out.println("}");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");
            
            ResultSet room = Util.getRoomByID(connection, Integer.valueOf(roomID));
            if(room == null)
            {
                out.println("The room with ID " + roomID + " does not exist.");
            }
            else
            {
                out.println("Room ID: <b>" + room.getString("roomID") + "</b><br>");
                out.println("Room Name: <b>" + room.getString("roomName") + "</b><br>");
                out.println("<br>");
                
                ResultSet upcomingAppointments = Util.getAppointmentByRoom(connection, Integer.valueOf(roomID), true);
                if(upcomingAppointments == null)
                    out.println("There are no upcoming appointments in this room.");
                else
                {
                    out.println("Upcoming Appointments:<br>");
                    out.println("<table>");
                    out.println("<tr>");
                    out.println("<th>Appointment ID</th>");
                    out.println("<th>Patient ID</th>");
                    out.println("<th>Patient's Name</th>");
                    out.println("<th>Doctor ID</th>");
                    out.println("<th>Doctor's Name</th>");
                    out.println("<th>Room ID</th>");
                    out.println("<th>Room Name</th>");
                    out.println("<th>Date</th>");
                    out.println("<th>Start Time</th>");
                    out.println("<th>End Time</th>");
                    out.println("<th>Note</th>");
                    out.println("</tr>");

                    upcomingAppointments.beforeFirst();
                    while (upcomingAppointments.next())
                    {
                        String patientFullName = Util.getPatientFullName(connection, upcomingAppointments.getInt("patientID"));
                        String doctorFullName = Util.getDoctorFullName(connection, upcomingAppointments.getInt("doctorID"));
                        String roomName = Util.getRoomName(connection, upcomingAppointments.getInt("roomID"));

                        out.println("<tr>");
                        out.println("<td>" + upcomingAppointments.getString("appointmentID") + "</td>");
                        out.println("<td>" + upcomingAppointments.getString("patientID") + "</td>");
                        out.println("<td>" + patientFullName + "</td>");
                        out.println("<td>" + upcomingAppointments.getString("doctorID") + "</td>");
                        out.println("<td>" + doctorFullName + "</td>");
                        out.println("<td>" + upcomingAppointments.getString("roomID") + "</td>");
                        out.println("<td>" + roomName + "</td>");
                        out.println("<td>" + upcomingAppointments.getString("date") + "</td>");
                        out.println("<td>" + upcomingAppointments.getString("startTime") + "</td>");
                        out.println("<td>" + upcomingAppointments.getString("endTime") + "</td>");
                        out.println("<td>" + upcomingAppointments.getString("Note") + "</td>");
                        out.println("</tr>");
                    }
                    
                    out.println("</table>");
                }
            }
            
            
            out.println("</body>");
            out.println("</html>");
        }
        catch(Exception ex)
        {}
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo()
    {
        return "Short description";
    }// </editor-fold>

    public static void connectToDatabase() throws Exception
    {
        // Load the driver.
        Class.forName("com.mysql.jdbc.Driver");

        // Connect to the database
        connection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);    
    }
}
