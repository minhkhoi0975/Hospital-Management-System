package CSC285.project.hospitalmanagementsystem.presentation.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SearchDoctorsByLastName extends HttpServlet
{
    final static String DATABASE_URL = "jdbc:mysql://localhost/hospitalmanagementsystem";
    final static String USERNAME = "root";
    final static String PASSWORD = "root";
    
    static Connection connection = null;
    
    public void init() throws ServletException
    {
        try
        {
             connectToDatabase();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {   
        response.setContentType("text/html;charset=UTF-8");

        String lastName = request.getParameter("lastName").trim();

        // Review the data.
        try (PrintWriter out = response.getWriter())
        {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Search Doctors by Last Name</title>");
            out.println("<style>");
            out.println("table, th, td {");
            out.println("border: 1px solid black;");
            out.println("border-collapse: collapse;");
            out.println("}");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");
            out.println("Last Name: <b>" + lastName + "</b><br>");

            // Get all doctor from database.
            Statement getDoctorStmt = connection.createStatement();
            ResultSet doctors = getDoctorStmt.executeQuery("select * from Doctor where lastName='" + lastName + "'");

            out.println("<table>");
            out.println("<tr>");
            out.println("<th>Doctor ID</th>");
            out.println("<th>First Name</th>");
            out.println("<th>Middle Name</th>");
            out.println("<th>Last Name</th>");
            out.println("<th>Sex</th>");
            out.println("<th>Date Of Birth</th>");
            out.println("<th>Phone Number</th>");
            out.println("<th>Home Address</th>");
            out.println("<th>Email Address</th>");
            out.println("<th>Department</th>");
            out.println("</tr>");

            while (doctors.next())
            {
                out.println("<tr>");
                out.println("<td>" + doctors.getString("doctorID") + "</td>");
                out.println("<td>" + doctors.getString("firstName") + "</td>");
                out.println("<td>" + doctors.getString("middleName") + "</td>");
                out.println("<td>" + doctors.getString("lastName") + "</td>");
                out.println("<td>" + (doctors.getString("isFemale").equals("1") ? "Female" : "Male") + "</td>");
                out.println("<td>" + doctors.getString("dateOfBirth") + "</td>");
                out.println("<td>" + doctors.getString("phoneNumber") + "</td>");
                out.println("<td>" + doctors.getString("homeAddress") + "</td>");
                out.println("<td>" + doctors.getString("emailAddress") + "</td>");
                out.println("<td>" + doctors.getString("department") + "</td>");
                out.println("</tr>");
            }

            out.println("</table>");
            out.println("</body>");
            out.println("</html>");
        } 
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo()
    {
        return "Short description";
    }// </editor-fold>

    public static void connectToDatabase() throws Exception
    {
        // Load the driver.
        Class.forName("com.mysql.jdbc.Driver");

        // Connect to the database
        connection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);    
    }  
}