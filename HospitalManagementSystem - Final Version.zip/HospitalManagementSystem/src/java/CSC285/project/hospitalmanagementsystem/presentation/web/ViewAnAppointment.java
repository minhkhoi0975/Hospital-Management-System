package CSC285.project.hospitalmanagementsystem.presentation.web;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import CSC285.project.hospitalmanagementsystem.dao.Util;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ViewAnAppointment extends HttpServlet
{
    final static String DATABASE_URL = "jdbc:mysql://localhost/hospitalmanagementsystem";
    final static String USERNAME = "root";
    final static String PASSWORD = "root";
    
    static Connection connection = null;
    
    public void init() throws ServletException
    {
        try
        {
             connectToDatabase();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
        
        // Retrieve data from the html page.   
        String appointmentID = request.getParameter("appointmentID").trim();
        
        try (PrintWriter out = response.getWriter())
        {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>View an Appointment</title>");            
            out.println("</head>");
            out.println("<body>");
            
            // Get the appointment from database.
            ResultSet appointment = Util.getAppointmentByID(connection, Integer.valueOf(appointmentID));
            
            // Check if the appointment exists
            if(appointment == null)
            {
                out.println("The doctor with ID " + appointmentID + " does not exist.<br>");
            }
            
            else
            {
                // Update the appointment.
                try
                {
                    int patientID = appointment.getInt("patientID");
                    String patientFullName = Util.getPatientFullName(connection, patientID);
                    int doctorID = appointment.getInt("doctorID");
                    String doctorFullName = Util.getDoctorFullName(connection, doctorID);
                    int roomID = appointment.getInt("roomID");
                    String roomName = Util.getRoomName(connection, roomID);
                    
                    out.println("Appointment ID: <b>" + appointmentID + "</b><br>");
                    out.println("Patient ID: <b>" + patientID + "</b><br>");
                    out.println("Patient's Name: <b>" + patientFullName + "</b><br>");
                    out.println("Doctor ID: <b>" + doctorID + "</b><br>");
                    out.println("Doctor's Name: <b>" + doctorFullName + "</b><br>");
                    out.println("Room ID: <b>" + roomID + "</b><br>");
                    out.println("Room Name: <b>" + roomName + "</b><br>");
                    out.println("Date: <b>" + appointment.getString("date") + "</b><br>");
                    out.println("Start Time: <b>" + appointment.getString("startTime") + "</b><br>");
                    out.println("End Time: <b>" + appointment.getString("endTime") + "</b><br>");
                    out.println("Note: <b>" + appointment.getString("note") + "</b><br>");
                } 
                catch (Exception ex)
                {
                    ex.printStackTrace();
                }                       
            }
            
            out.println("</body>");
            out.println("</html>");       
        }
        catch(Exception ex)
        {}
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo()
    {
        return "Short description";
    }// </editor-fold>

    public static void connectToDatabase() throws Exception
    {
        // Load the driver.
        Class.forName("com.mysql.jdbc.Driver");

        // Connect to the database
        connection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);      
    }
}
