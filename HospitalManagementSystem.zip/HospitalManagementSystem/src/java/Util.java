import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.Time;
import java.sql.Date;

public class Util
{
    public static ResultSet getRows(Connection connection, String tableName) throws SQLException
    {
        try
        {
            Statement getRowsStmt = connection.createStatement();
            ResultSet rows = getRowsStmt.executeQuery("select * from " + tableName);
            if(!rows.first())
                return null;
            else
                return rows;
        }
        catch(SQLException ex)
        {
            return null;
        }
    }
    
    public static ResultSet getRows(Connection connection, String tableName, String condition) throws SQLException
    {
        try
        {
            Statement getRowsStmt = connection.createStatement();
            ResultSet rows = getRowsStmt.executeQuery("select * from " + tableName + " where " + condition);
            if(!rows.first())
                return null;
            else
                return rows;
        }
        catch(SQLException ex)
        {
            return null;
        }
    }
    
    public static ResultSet getRows(Connection connection, String tableName, String condition, String order) throws SQLException
    {
        try
        {
            Statement getRowsStmt = connection.createStatement();
            ResultSet rows = getRowsStmt.executeQuery("select * from " + tableName + " where " + condition + " order by " + order);
            if(!rows.first())
                return null;
            else
                return rows;
        }
        catch(SQLException ex)
        {
            return null;
        }
    }
    
    public static ResultSet getPatients(Connection connection) throws SQLException
    {
        return getRows(connection, "Patient");
    }
    
    public static ResultSet getPatientByID(Connection connection, int patientID) throws SQLException
    {
        return getRows(connection, "Patient", "medicalRecordNumber=" + patientID);
    }
    
    public static String getPatientFullName(Connection connection, int patientID) throws SQLException
    {
        ResultSet patient = getPatientByID(connection, patientID);
        
        if(patient == null)
            return "";
        else
        {
            patient.first();
            return patient.getString("firstName") + " "
                    + (patient.getString("middleName").equals("") ? "" : patient.getString("middleName") + " ")
                    + (patient.getString("lastName"));
        }
    }
    
    public static ResultSet getPatientsByAssignedDoctor(Connection connection, int assignedDoctorID) throws SQLException
    {
        return getRows(connection, "Patient", "assignedDoctorID=" + assignedDoctorID);
    }
    
    public static ResultSet getDoctors(Connection connection) throws SQLException
    {
        return getRows(connection, "Doctor");
    }
    
    public static ResultSet getDoctorByID(Connection connection, int doctorID) throws SQLException
    {
        return getRows(connection, "Doctor", "doctorID=" + doctorID);
    }
    
    public static String getDoctorFullName(Connection connection, int doctorID) throws SQLException
    {
        ResultSet doctor = getDoctorByID(connection, doctorID);
        
        if(doctor == null)
            return "";
        else
        {
            doctor.first();
            return doctor.getString("firstName") + " "
                    + (doctor.getString("middleName").equals("") ? "" : doctor.getString("middleName") + " ")
                    + (doctor.getString("lastName"));
        }
    }
    
    public static ResultSet getRooms(Connection connection) throws SQLException
    {
        return getRows(connection, "Room");
    }
    
    public static ResultSet getRoomByID(Connection connection, int roomID) throws SQLException
    {
        return getRows(connection, "Room", "roomID=" + roomID);
    }
    
    public static String getRoomName(Connection connection, int roomID) throws SQLException
    {
        ResultSet room = getRoomByID(connection, roomID);
        
        if(room == null)
            return "";
        else
        {
            room.first();
            return room.getString("roomName");
        }
    }
    
    public static ResultSet getAppointments(Connection connection) throws SQLException
    {
        return getRows(connection, "Appointment");
    }
    
    public static ResultSet getAppointmentByID(Connection connection, int appointmentID) throws SQLException
    {
        return getRows(connection, "Appointment", "appointmentID=" + appointmentID);
    }
    
    public static ResultSet getAppointmentByPatient(Connection connection, int patientID) throws SQLException
    {
        return getRows(connection, "Appointment", "patientID=" + patientID, "date, startTime");
    }
    
    public static ResultSet getAppointmentByPatient(Connection connection, int patientID, boolean excludePastAppointments) throws SQLException
    {
        if(!excludePastAppointments)
            return getRows(connection, "Appointment", "patientID=" + patientID, "date, startTime");
        else
            return getRows(connection, "Appointment", "patientID=" + patientID + " and date>=current_date()", "date, startTime");
    }
    
    public static ResultSet getAppointmentsByDoctor(Connection connection, int doctorID) throws SQLException
    {
        return getRows(connection, "Appointment", "doctorID=" + doctorID, "date, startTime");
    }
    
    public static ResultSet getAppointmentByDoctor(Connection connection, int doctorID, boolean excludePastAppointments) throws SQLException
    {
        if(!excludePastAppointments)
            return getRows(connection, "Appointment", "doctorID=" + doctorID, "date, startTime");
        else
            return getRows(connection, "Appointment", "doctorID=" + doctorID + " and date>=current_date()", "date, startTime");
    }
    
    public static ResultSet getAppointmentsByRoom(Connection connection, int roomID) throws SQLException
    {
        return getRows(connection, "Appointment", "roomID=" + roomID, "date, startTime");
    }
    
    public static ResultSet getAppointmentByRoom(Connection connection, int roomID, boolean excludePastAppointments) throws SQLException
    {
        if(!excludePastAppointments)
            return getRows(connection, "Appointment", "roomID=" + roomID, "date, startTime");
        else
            return getRows(connection, "Appointment", "roomID=" + roomID + " and date>=current_date()", "date, startTime");
    }
    
    public static ResultSet getUpcomingAppointments(Connection connection) throws SQLException
    {
        return getRows(connection, "Appointment", "date>=current_date()", "date, startTime");
    }
    
    public static boolean patientHasAppointment(Connection connection, int patientID, Date date, Time startTime, Time endTime) throws SQLException
    {
        String query = "select * from Appointment where patientID = ? and date = ? and ((? >= startTime and ? <= endTime) or (? >= startTime and ? <= endTime))" ;
        PreparedStatement assignDoctorStmt = connection.prepareStatement(query);            
        assignDoctorStmt.setInt(1, patientID);     
        assignDoctorStmt.setDate(2, date);
        assignDoctorStmt.setTime(3, startTime);
        assignDoctorStmt.setTime(4, startTime);
        assignDoctorStmt.setTime(5, endTime);
        assignDoctorStmt.setTime(6, endTime);
        ResultSet appointments = assignDoctorStmt.executeQuery();
        return appointments.first();
    }
    
    public static boolean patientHasAppointment(Connection connection, int patientID, Date date, Time startTime, Time endTime, int exceptedAppointmentID) throws SQLException
    {
        String query = "select * from Appointment where appointmentID != " + exceptedAppointmentID 
                + " and patientID = ? and date = ? and ((? >= startTime and ? <= endTime) or (? >= startTime and ? <= endTime))" ;
        PreparedStatement assignDoctorStmt = connection.prepareStatement(query);            
        assignDoctorStmt.setInt(1, patientID);     
        assignDoctorStmt.setDate(2, date);
        assignDoctorStmt.setTime(3, startTime);
        assignDoctorStmt.setTime(4, startTime);
        assignDoctorStmt.setTime(5, endTime);
        assignDoctorStmt.setTime(6, endTime);
        ResultSet appointments = assignDoctorStmt.executeQuery();
        return appointments.first();
    }
    
    public static boolean doctorHasAppointment(Connection connection, int doctorID, Date date, Time startTime, Time endTime) throws SQLException
    {
        String query = "select * from Appointment where doctorID = ? and date = ? and ((? >= startTime and ? <= endTime) or (? >= startTime and ? <= endTime))" ;
        PreparedStatement assignDoctorStmt = connection.prepareStatement(query);            
        assignDoctorStmt.setInt(1, doctorID);     
        assignDoctorStmt.setDate(2, date);
        assignDoctorStmt.setTime(3, startTime);
        assignDoctorStmt.setTime(4, startTime);
        assignDoctorStmt.setTime(5, endTime);
        assignDoctorStmt.setTime(6, endTime);
        ResultSet appointments = assignDoctorStmt.executeQuery();
        return appointments.first();
    }
    
    public static boolean doctorHasAppointment(Connection connection, int doctorID, Date date, Time startTime, Time endTime, int exceptedAppointmentID) throws SQLException
    {
        String query = "select * from Appointment where appointmentID != " + exceptedAppointmentID 
                + " and doctorID = ? and date = ? and ((? >= startTime and ? <= endTime) or (? >= startTime and ? <= endTime))" ;
        PreparedStatement assignDoctorStmt = connection.prepareStatement(query);            
        assignDoctorStmt.setInt(1, doctorID);     
        assignDoctorStmt.setDate(2, date);
        assignDoctorStmt.setTime(3, startTime);
        assignDoctorStmt.setTime(4, startTime);
        assignDoctorStmt.setTime(5, endTime);
        assignDoctorStmt.setTime(6, endTime);
        ResultSet appointments = assignDoctorStmt.executeQuery();
        return appointments.first();
    }
    
    public static boolean roomHasAppointment(Connection connection, int roomID, Date date, Time startTime, Time endTime) throws SQLException
    {
        String query = "select * from Appointment where roomID = ? and date = ? and ((? >= startTime and ? <= endTime) or (? >= startTime and ? <= endTime))" ;
        PreparedStatement assignDoctorStmt = connection.prepareStatement(query);            
        assignDoctorStmt.setInt(1, roomID);     
        assignDoctorStmt.setDate(2, date);
        assignDoctorStmt.setTime(3, startTime);
        assignDoctorStmt.setTime(4, startTime);
        assignDoctorStmt.setTime(5, endTime);
        assignDoctorStmt.setTime(6, endTime);
        ResultSet appointments = assignDoctorStmt.executeQuery();
        return appointments.first();
    }
    
    public static boolean roomHasAppointment(Connection connection, int roomID, Date date, Time startTime, Time endTime, int exceptedAppointmentID) throws SQLException
    {
        String query = "select * from Appointment where appointmentID != " + exceptedAppointmentID 
                + " and roomID = ? and date = ? and ((? >= startTime and ? <= endTime) or (? >= startTime and ? <= endTime))" ;
        PreparedStatement assignDoctorStmt = connection.prepareStatement(query);            
        assignDoctorStmt.setInt(1, roomID);     
        assignDoctorStmt.setDate(2, date);
        assignDoctorStmt.setTime(3, startTime);
        assignDoctorStmt.setTime(4, startTime);
        assignDoctorStmt.setTime(5, endTime);
        assignDoctorStmt.setTime(6, endTime);
        ResultSet appointments = assignDoctorStmt.executeQuery();
        return appointments.first();
    }
}
