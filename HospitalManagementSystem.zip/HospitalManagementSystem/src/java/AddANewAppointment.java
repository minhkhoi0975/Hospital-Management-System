import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class AddANewAppointment extends HttpServlet
{
    final static String DATABASE_URL = "jdbc:mysql://localhost/hospitalmanagementsystem";
    final static String USERNAME = "root";
    final static String PASSWORD = "root";
    
    static Connection connection = null;
    static PreparedStatement statement = null;
    
    public void init() throws ServletException
    {
        try
        {
             connectToDatabase();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
        
        // Retrieve data from the html page.     
        String patientID = request.getParameter("patientID").trim();
        String doctorID = request.getParameter("doctorID").trim();
        String roomID = request.getParameter("roomID").trim();
        
        String dateString = request.getParameter("date");
        Date date = new Date(0);
        try
        {
            date = new SimpleDateFormat("yyyy-MM-dd").parse(dateString);
        }
        catch(ParseException ex)
        {}
        
        String startTimeString = request.getParameter("startTime");
        Time startTime = new Time(0);   
        try
        {
            startTime = new Time(new SimpleDateFormat("HH:mm").parse(startTimeString).getTime());
        }
        catch(ParseException ex)
        {}
        
        String endTimeString = request.getParameter("endTime");
        Time endTime = new Time(0);   
        try
        {
            endTime = new Time(new SimpleDateFormat("HH:mm").parse(endTimeString).getTime());
        }
        catch(ParseException ex)
        {}
        
        String note = request.getParameter("note").trim();
            
        // Review the data.
        try (PrintWriter out = response.getWriter())
        {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Add a New Appointment</title>");            
            out.println("</head>");
            out.println("<body>");
                 
            // Get the patient from database.
            Statement getPatientStmt = connection.createStatement();
            ResultSet patient = getPatientStmt.executeQuery("select * from Patient where medicalRecordNumber=" + patientID);
                     
            // Get the doctor from database.
            Statement getDoctorStmt = connection.createStatement();
            ResultSet doctor = getDoctorStmt.executeQuery("select * from Doctor where doctorID=" + doctorID);
            
            // Get the room from database.
            Statement getRoomStmt = connection.createStatement();
            ResultSet room = getRoomStmt.executeQuery("select * from Room where roomID=" + roomID);
            
            // Check if the patient exists
            if(!patient.first())
            {
                out.println("The patient with ID " + patientID + " does not exist.<br>");
            }
            
            // Check if the doctor exists.
            else if(!doctor.first())
            {
                out.println("The doctor with ID " + doctorID + " does not exist.<br>");
            }
            
            // Check if the room exists.
            else if(!room.first())
            {
                out.println("The room with ID " + doctorID + " does not exist.<br>");
            }
            
            // Check if the patient has another appointment that matches the time range.
            else if(Util.patientHasAppointment(connection, Integer.valueOf(patientID), new java.sql.Date(date.getYear(), date.getMonth(), date.getDate()), startTime, endTime))
            {
                out.println("Cannot add a new appointment: The patient has another appointment that matches the time range.<br>");
            }
            
            // Check if the doctor has another appointment that matches the time range.
            else if(Util.doctorHasAppointment(connection, Integer.valueOf(doctorID), new java.sql.Date(date.getYear(), date.getMonth(), date.getDate()), startTime, endTime))
            {
                out.println("Cannot add a new appointment: The doctor has another appointment that matches the time range.<br>");
            }
            
            // Check if the room has another appointment that matches the time range.
            else if(Util.roomHasAppointment(connection, Integer.valueOf(roomID), new java.sql.Date(date.getYear(), date.getMonth(), date.getDate()), startTime, endTime))
            {
                out.println("Cannot add a new appointment: The room has another appointment that matches the time range.<br>");
            }
            
            else
            {
                // Add the new record to the database.
                addANewAppointment(getNumOfRecords(connection, "Appointment"),
                        Integer.valueOf(patientID), Integer.valueOf(doctorID), Integer.valueOf(roomID), 
                        new java.sql.Date(date.getYear(), date.getMonth(), date.getDate()), startTime, endTime, 
                        note);
                
                String patientFullName = Util.getPatientFullName(connection, patient.getInt("medicalRecordNumber"));               
                String doctorFullName = Util.getDoctorFullName(connection, doctor.getInt("doctorID"));
                String roomName = room.getString("roomName");
                
                out.println("Review<br>");
                out.println("Appointment ID: <b>" + (getNumOfRecords(connection, "Appointment")-1) + "</b><br>");
                out.println("Patient ID: <b>" + patientID + "</b><br>");
                out.println("Patient's Name: <b>" + patientFullName + "</b><br>");
                out.println("Doctor ID: <b>" + doctorID + "</b><br>");
                out.println("Doctor's Name: <b>" + doctorFullName + "</b><br>");
                out.println("Room ID: <b>" + roomID + "</b><br>");
                out.println("Room Name: <b>" + roomName + "</b><br>");
                out.println("Date: <b>" + (date.getMonth() + 1) + "/" + date.getDate() + "/" + (date.getYear() + 1900) + "</b><br>");
                out.println("Start Time: <b>" + startTimeString + "</b><br>");
                out.println("End Time: <b>" + endTimeString + "</b><br>");
                out.println("Note: <b>" + note + "</b><br>");
            }
            
            
            out.println("</body>");
            out.println("</html>");
        }
        catch(Exception ex)
        {}
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo()
    {
        return "Short description";
    }// </editor-fold>

    public static void connectToDatabase() throws Exception
    {
        // Load the driver.
        Class.forName("com.mysql.jdbc.Driver");

        // Connect to the database
        connection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);

        // Prepare the insert statement.
        String query = " insert into Appointment (appointmentID, patientID, doctorID, roomID, date, startTime, endTime, note)"
                + " values(?, ?, ?, ?, ?, ?, ?, ?)";
        statement = connection.prepareStatement(query);      
    }
    
    public static void addANewAppointment(int id, 
            int patientID, int doctorID, int roomID, 
            java.sql.Date date, java.sql.Time startTime, java.sql.Time endTime,
            String note) throws Exception
    {   
        statement.setInt(1, id);
        statement.setInt(2, patientID);
        statement.setInt(3, doctorID);
        statement.setInt(4, roomID);
        statement.setDate(5, date);
        statement.setTime(6, startTime);
        statement.setTime(7, endTime);
        statement.setString(8, note);
        statement.executeUpdate();
    }
    
    public static int getNumOfRecords(Connection connection, String tableName) throws SQLException
    {
        Statement countRecordsStmt = connection.createStatement();
        ResultSet resultSet = countRecordsStmt.executeQuery("select count(*) from " + tableName);
        resultSet.next();
        return resultSet.getInt(1);
    }
}
