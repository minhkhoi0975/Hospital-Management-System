How to run the project:

1. Extract the contents in the .zip file

2. Use mysqldump to create a database from the .sql file
   + Open command prompt (cmd).
   + cd to the "bin" folder that contains mysqldump (e.g. cd C:/program files/MySQL/MySQL Server5.1/bin).
   + Use the command below to create a database from the .sql file:
     mysqldump -u[username] -p[password] [database name] < [full path of the .sql file]
     (e.g. mysqldump -uroot -proot hospitalmanagementsystem < C:/JavaProjects/HospitalManagementSystem/database/hospitalmanagementsystem.sql)
   The program will not work if the database does not exist.

3. Open the project in NetBeans

4. Check dependencies
   In the "project" window, go to HospitalManagementSystem->Libraries and check if "javaee-endorsed-api-7.0.jar" and "mysql-connector-java-5.1.49.jar" exist.
   If they don't, right click, select "Add JAR/Folder..." and add those files to the project. They are in the "dependencies" folder.
   These files are important: The first one is used to create web apps, and the second one is used to get access to database.

5. Create a Tomcat server
   + In the menu bar, select Tools->Servers.
   + In the "Server" window, click the "Add Server..." button.
   + Select "Apache Tomcat or TomEE" and enter the server name, then click "Next".
   + For the "Server Location", enter the path to Apache Tomcat (e.g C:\JavaProjects\apache-tomcat-9.0.39).
   + Enter the username and password and select "Create user if it does not exist", then click "Finish".
   + In the "Server" window, make sure that the Server Port is 8080 and the Shutdown Port is 8005.
   
6. Test the program.
   + In the project window, select HospitalManagementSystem, right click and select "Run".
   + Enter the username and password of your Tomcat server.
   + Test the program.
   
If you have any problems, please email me (kdho@bhcc.edu).
For references, they are in the "references" folder.
